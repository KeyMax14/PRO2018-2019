/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicionalmedianotas;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García <kevinhg94@gmail.com>
 */
public class AdicionalMediaNotas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
            Calcular las medias de las notas de un usuario, las media termina cuando se 
            introduce un valor negativo.
        */
        Scanner sc = new Scanner(System.in);
        int suma = 0;
        int valor = 0;
        int i;
        for (i = 0; valor >= 0.0; i++) {
            suma += valor;
            System.out.println("Introduce la nota número "+(i+1)+".");
            valor = sc.nextInt();
        }
        System.out.println("La media es "+ (suma/(double)(i-1))+".");
    }
    
}
