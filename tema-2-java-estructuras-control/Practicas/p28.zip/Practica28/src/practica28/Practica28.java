/*
    Práctica 28 Hacer un programa que el usuario vaya introduciendo números enteros. El
    programa finaliza cuando el usuario introduce el número 0. En ese momento se le muestra
    la suma total de los números positivos y la suma total de los números negativos
 */
package practica28;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García <kevinhg94@gmail.com>
 */
public class Practica28 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce una serie de número enteros: acaba con 0");
        int sumaNegativa = 0;
        int sumaPositiva = 0;
        int num = sc.nextInt();;
        
        while (num != 0){
            if (num > 0){
                sumaPositiva += num;
            }else{
                sumaNegativa += num;
            }
            num = sc.nextInt();
        }
        System.out.println("La suma positiva es "+sumaPositiva+".");
        System.out.println("La suma negativa es "+sumaNegativa+".");
    }
    
}
