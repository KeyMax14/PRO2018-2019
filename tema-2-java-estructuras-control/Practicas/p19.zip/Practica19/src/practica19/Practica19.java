/*
Práctica 19: Realizar un programa que sirva para convertir grados Farenheit en centígrados
El usuario introducirá los grados Farenheit y se le mostrará la equivalencia en centígrados.
La fórmula es:.
C = ( F – 32 ) * 5/9
donde C es grados centígrados y F es Farenheit
 */
package practica19;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García <kevinhg94@gmail.com>
 */
public class Practica19 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Introduzca los grados en farenheit: ");
        Scanner sc = new Scanner(System.in);
        double f = sc.nextDouble();
        double c = (f-32)*(5/(double)9);
        System.out.println(f+"Fº equivalen a "+c+"Cº.");
    }
    
}
