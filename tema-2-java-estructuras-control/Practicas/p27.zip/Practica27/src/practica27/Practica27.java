/*
    Práctica 27: Hacer un programa que muestre la tabla de multiplicar del número 5 usando
        un bucle while.
 */
package practica27;

/**
 *
 * @author Kevin Hernández García <kevinhg94@gmail.com>
 */
public class Practica27 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int i = 1;
        while (i <=10) {
            System.out.println("5 x "+i+" = "+(5*i));
            i++;
        }
    }
    
}
