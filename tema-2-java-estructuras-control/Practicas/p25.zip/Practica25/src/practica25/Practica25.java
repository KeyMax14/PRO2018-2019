/*
    Práctica 25: Hacer un programa que le pida al usuario que introduzca una letra y por
    medio de una estructura switch, evitando el mayor número de sentencias break posibles ,
    muestre en pantalla el mensaje: “es una vocal” cuando el usuario haya introducido una
    vocal ( ya sea minúscula o mayúscula ) y el mensaje: “no es una vocal” si no lo fuera.
 */
package practica25;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García <kevinhg94@gmail.com>
 */
public class Practica25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Introduce un caracter: ");
        Scanner sc = new Scanner(System.in);
        
        String palabra = sc.nextLine();
        palabra = palabra.toLowerCase(); // Transforma la palabra a minuscula. 
        char c = palabra.charAt(0); // String es como un array de caracteres, elige char0.
        switch(c){
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                System.out.println("Es una vocal."); break;
            default:
                System.out.println("No es una vocal.");
        
        }
    }
    
}
