/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adicionalifrangos;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García <kevinhg94@gmail.com>
 */
public class AdicionalIfRangos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*  
            Hacer un programa que el usuario introduce un numero 
        
        si el numero esta entre [0, 10) mostrar 
        "Es menor de 10"
        
        Si el número esta entre [10, 15) mostrar
        "Está entre 10 y 15"
        
        Si el número es mayo o igual que 15 moestrar
        "Es mayor o igual a 15"
        */
        
        System.out.println("Introduce un número entero positivo: ");
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        
        /* Forma original
        if (num >=0 && num < 10){  
            System.out.println("Es menor de 10.");
        }else{
            if (num >= 10 && num < 15){
                System.out.println("Está entre 10 y 15.");
            }else{
                if (num >= 15){
                    System.out.println("Es mayor o igual a 15");
                }else{
                    System.out.println("No es un número positivo.");
                }
            }
        }
        */
        // Mejor forma
        if (num >=0 && num < 10){  
            System.out.println("Es menor de 10.");
        }else if (num >= 10 && num < 15){
            System.out.println("Está entre 10 y 15.");
        }else if (num >= 15){
            System.out.println("Es mayor o igual a 15");
        }else{
            System.out.println("No es un número positivo.");
        }
    }
    
}
