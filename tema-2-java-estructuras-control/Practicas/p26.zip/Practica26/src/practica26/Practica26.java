/*
    Práctica 26: Escribe un programa que pida por teclado un día de la semana ( ún número
    entero del 1 al 5 que representa de lunes a viernes ) y que diga qué asignatura toca a primera
    hora ese día.

    // Modificamos esto introduciendo el dia de la semanas.
 */
package practica26;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García <kevinhg94@gmail.com>
 */
public class Practica26 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Introduce el dia de la semana: ");
        Scanner sc = new Scanner(System.in);
        String dia = sc.next();
        
        dia = dia.toLowerCase();
        
        switch(dia){
            case "lunes": 
            case "miercoles": 
                System.out.println("LND"); break;
            case "martes": 
            case "viernes":
                System.out.println("PRO"); break;
            case "jueves": 
                System.out.println("LNT"); break;
            case "sabado":
            case "domingo":
                System.out.println("No hay clase."); break;
            default:
                System.out.println("No reconozco ese dia.");
        }
          
    }
    
}
