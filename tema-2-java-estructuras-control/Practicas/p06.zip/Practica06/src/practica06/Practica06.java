/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica06;

/**
 *
 * @author daw
 */
public class Practica06 {

//    Práctica 6: Escribe un programa que muestre tu horario de clase. Puedes usar espacios o
//tabuladores para alinear el texto.
    public static void main(String[] args) {
        System.out.println("\t\tHorario");
        System.out.println("Hora\tL\tM\tX\tJ\tV\n");
        System.out.println("14:15\t   \tPRO\t   \t   \tPRO\n");
        System.out.println("15:10\t   \tPRO\t   \t   \tPRO\n");
        System.out.println("16:05\tPRO\t   \t   \t   \t   \n");
        System.out.println("17:00\tR  \tE  \tCR \tE  \tO  \n");
        System.out.println("17:15\t   \t   \t   \tETS\t   \n");
        System.out.println("18:10\tETS\t   \t   \tPRO\t   \n");
        System.out.println("19:05\tETS\t   \t   \tPRO\t   \n");
    }
    
}
