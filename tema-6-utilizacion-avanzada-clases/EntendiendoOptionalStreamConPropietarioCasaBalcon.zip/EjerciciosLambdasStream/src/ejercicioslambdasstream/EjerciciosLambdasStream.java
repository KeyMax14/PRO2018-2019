/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioslambdasstream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Optional;
import java.util.Random;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author carlos
 */


public class EjerciciosLambdasStream {

    /**
     * @param args the command line arguments
     */
    
    static double contador=0;
    
    
    public static void main(String[] args) {
        ArrayList<Persona> personas = new ArrayList<Persona>();
        personas.add(new Hombre("Manuel","Fernández", 23, 210, 75));
        personas.add(new Mujer("Marta","Díaz", 25, 235, 55));
        personas.add(new Hombre("Luis","Fernández", 20, 210, 70));
        personas.add(new Mujer("Ana","Díaz", 23, 270, 65));
        personas.add(new Hombre("Armando","San Miguel", 29, 175, 77));   




        
        

        
    }
    
}
