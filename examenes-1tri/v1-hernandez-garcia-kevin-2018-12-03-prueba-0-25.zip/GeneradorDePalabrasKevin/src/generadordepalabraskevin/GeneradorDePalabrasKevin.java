/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generadordepalabraskevin;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García <kevinhg94@gmail.com>
 */
public class GeneradorDePalabrasKevin {


    public static String vocalesAleatorias(){
        Random rnd = new Random();
        String resultado = "";
        String[] letras = {"a","e","i","o","u"};
        resultado += letras[rnd.nextInt(letras.length)];
        resultado += letras[rnd.nextInt(letras.length)];
        return resultado;
    }
    
        public static String consonanteAleatoria(){
        Random rnd = new Random();
        String resultado = "";
        String[] letras = {"b","c","d","f","g","h","j","k","l","m","n","p","q","r","s","t","v","w","x","y","z"};
        resultado += letras[rnd.nextInt(letras.length)];
        return resultado;
    }
        
    public static boolean esVocal(int letra){
        boolean res = false;
        if(letra == (int)'A' || letra == (int)'E' || letra == (int)'I' || letra == (int)'O' || letra == (int)'U'){
            res = true;
        }
        return res;
    }
    
    
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Generador de palabras aleatorias");
        System.out.println("Se creará una palabra desde la letra dada\n"
                + "hasta el final del abecedario\n"
                + "letra: ");
        String letra = sc.nextLine();
        char PrimeraLetra = letra.toUpperCase().charAt(0);
        
        for (int i = (int)PrimeraLetra ; i <= 'Z'; i++) {
            if (esVocal(i)) {
                System.out.println(""+(char)i+consonanteAleatoria());
            }else{
                System.out.println(""+(char)i+vocalesAleatorias());
            }
        }
    }

}
