/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenkevinparte2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García
 */
public class Ejercicio7 {

    public static void main(String[] args) {
        Random rnd = new Random();
        Scanner sc = new Scanner(System.in);
        String[] posibilidades = {"piedra","papel","tijeras"};
        int opcion;
        int opcionMaquina;
        do {
            System.out.println("Elegir piedra, papel, tijeras");
            System.out.println("0) piedra");
            System.out.println("1) papel");
            System.out.println("2) tijeras");
            opcion = sc.nextInt();
            opcionMaquina = rnd.nextInt(3);
            if (opcion==opcionMaquina) {
                System.out.println("Se ha sacado el mismo resultado: "+posibilidades[opcion]+"\n");
            }
        } while (opcion == opcionMaquina);
        
        if (opcion == 0 && opcionMaquina == 1) {
            System.out.println("Gana Máquina ya que papel gana a piedra.");
        }else if (opcion == 0 && opcionMaquina == 2) {
            System.out.println("Gana Jugador ya que piedra gana a tijeras.");
        }else if (opcion == 1 && opcionMaquina == 0) {
            System.out.println("Gana Jugador ya que papel gana a piedra.");
        }else if (opcion == 1 && opcionMaquina == 2) {
            System.out.println("Gana Máquina ya que tijeras gana a papel.");
        }else if (opcion == 2 && opcionMaquina == 0) {
            System.out.println("Gana Máquina ya que piedra gana a tijeras.");
        }else if (opcion == 2 && opcionMaquina == 1) {
            System.out.println("Gana Jugador ya que tijeras gana a papel.");
        }


    }

}
