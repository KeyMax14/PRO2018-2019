/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenkevinparte2;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García
 */
public class Ejercicio6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce una letra: ");
        char letra = sc.next().toUpperCase().charAt(0);
        int inicio = (int) letra;
//        int fin = (inicio!=(int)'A')?(int)letra+1:(int)'Z';  Ignorar esto, es para revisar en casa.
        if (inicio != 'A') {
            while (inicio != (int) letra + 1) {
                System.out.print(letra + " ");
                letra++;
                letra = (letra > 'Z') ? 'A' : letra;
            }
            System.out.println(letra);
        } else {
            while (letra != 'Z') {
                System.out.print(letra + " ");
                letra++;

            }
            System.out.println(letra);
        }
    }

}
