/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenkevinparte2;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García
 */
public class Ejercicio8 {

    public static String cifrar(String subPalabra) {
        String resultado = "";
        if (subPalabra.length() > 1) {
            char letra = subPalabra.charAt(0);
            subPalabra = subPalabra.substring(1,subPalabra.length());
            switch (letra) {
                case 'x':
                    resultado = ""+'a'+ cifrar(subPalabra);
                    break;
                case 'y':
                    resultado =""+'b'+cifrar(subPalabra);
                    break;
                case 'z':
                    resultado =""+'c'+cifrar(subPalabra);
                    break;
                default:
                    letra = (char)(((int)letra)+3);
                    resultado = ""+letra+cifrar(subPalabra);
            }
        } else {
            char letra = subPalabra.charAt(0);
            switch (letra) {
                case 'x':
                    resultado = "" + 'a';
                    break;
                case 'y':
                    resultado = "" + 'b';
                    break;
                case 'z':
                    resultado = "" + 'c';
                    break;
                default:
                    letra = (char) (((int)letra)+3);
                    resultado = "" + letra;
            }
        }

        return resultado;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Intro palabra:");
        String palabra = sc.next();
        System.out.println("palabra cifrada:"+ cifrar(palabra));
        

    }
}
