/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenkevinparte2;

import java.util.Random;

/**
 *
 * @author Kevin Hernández García
 */
public class Ejercicio5 {
    public static int[] generarAleatorio(int size){
        Random rnd = new Random();
        int[] array = new int[size];
        for (int i = 0; i < array.length; i++) {
            array[i]=rnd.nextInt(100);
        }
        return array;
    }
    
    public static void mostrarArray(int[] array){
        System.out.print("[ ");
        for (int i = 0; i < array.length-1; i++) {
            System.out.print(array[i]+", ");
        }
        System.out.println(array.length-1+" ]");
    }
    
    public static double calculoEstadistico(String tipoCalculo, int[] array){
        double resultado = 0;
        if (tipoCalculo.equals("media")) {
            double media = 0;
            for (int i = 0; i < array.length; i++) {
                media += array[i];
            }
            media = media/(double)array.length;
            resultado= media;
        }else if (tipoCalculo.equals("maximo")) {
            int maximo = array[0];
            for (int i = 0; i < array.length; i++) {
                if (maximo < array[i]) {
                    maximo = array[i];
                }
            }
            resultado = maximo;
        }else if (tipoCalculo.equals("minimo")) {
            int minimo = array[0];
            for (int i = 0; i < array.length; i++) {
                if (minimo > array[i]) {
                    minimo = array[i];
                }
            }
            resultado = minimo;
        }else{
            System.out.println("Operacion incorrecta.");
            resultado = -1;
        }
           
        return resultado;
    }
    
    public static void main(String[] args) {
        int arr[] = generarAleatorio(10);
        mostrarArray(arr);
        System.out.println(calculoEstadistico("maximo", arr));
        System.out.println(calculoEstadistico("minimo", arr));
        System.out.println(calculoEstadistico("media", arr));
    }
}
