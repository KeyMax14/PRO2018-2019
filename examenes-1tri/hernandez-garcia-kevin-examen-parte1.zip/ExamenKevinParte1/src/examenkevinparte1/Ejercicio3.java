/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenkevinparte1;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García
 */
public class Ejercicio3 {
    
    public static void diaAnio(int n){
        
        switch (n%7) {
            case 0:
                System.out.println("Domingo");
                break;
            case 1:
                System.out.println("Lunes");
                break;
            case 2:
                System.out.println("Martes");
                break;
            case 3:
                System.out.println("Miercoles");
                break;
            case 4:
                System.out.println("Jueves");
                break;
            case 5:
                System.out.println("Viernes");
                break;
            case 6:
                System.out.println("Sabado");
                break;

        }
    
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce un día del año: 1-365");
        int diaAnio = sc.nextInt();
        if (diaAnio >=1 && diaAnio <=365) {
            diaAnio(diaAnio);
        }else
            System.out.println("Se debe introducir un número entre 1 y 365.");
    }
    
}
