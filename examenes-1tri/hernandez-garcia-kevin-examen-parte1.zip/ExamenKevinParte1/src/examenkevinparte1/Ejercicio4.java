/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenkevinparte1;

import java.util.Scanner;

/**
 *
 * @author Kevin Hernández García
 */
public class Ejercicio4 {

    public static boolean controlBase7(String num1String, String num2String) {
        boolean noBase7Num1 = true;
        boolean noBase7Num2 = true;
        boolean noNum1 = true;
        boolean noNum2 = true;
        while (noNum2 && noNum1 && noBase7Num1 && noBase7Num2) {

            for (int i = 0; i < num1String.length(); i++) {
                if (num1String.charAt(i) <= '0' && num1String.charAt(i) >= '9') {
                    noNum1 = false;
                }
                if (num1String.charAt(i) >= '7' && num1String.charAt(i) >= '9') {
                    noBase7Num1 = false;
                }
            }

            for (int i = 0; i < num2String.length(); i++) {
                if (num2String.charAt(i) <= '0' && num2String.charAt(i) >= '9') {
                    noNum2 = false;
                }
                if (num2String.charAt(i) >= '7' && num2String.charAt(i) >= '9') {
                    noBase7Num2 = false;
                }
            }
        }
        return noNum2 && noNum1 && noBase7Num1 && noBase7Num2;
    }

    public static int convertirNum(String num){
        int suma = 0;
        for (int i = 0; i < num.length(); i++) {
            suma += Integer.parseInt(num) * Math.pow(7, num.length()-1-i);
        }
        return suma;
    }

    

    public static void sumaBase7(String num1String, String num2String) {
        Scanner sc = new Scanner(System.in);
        int num1 = convertirNum(num1String);
        int num2 = convertirNum(num2String);
        System.out.println("La suma de los números es "+(num1+num2));

    }

    public static void divisionBase7(String num1String, String num2String) {
        Scanner sc = new Scanner(System.in);

    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce para elegir operación: ");
        System.out.println("1: Suma");
        System.out.println("2: Division");
        int eleccion = sc.nextInt();
        switch (eleccion) {
            case 1:
                System.out.println("Intro num1: ");
                String num1 = sc.nextLine();
                System.out.println("Intro num2: ");
                String num2 = sc.nextLine();
                sumaBase7(num1, num2);
                break;
            case 2:
                System.out.println("Intro num1: ");
                String num3 = sc.nextLine();
                System.out.println("Intro num2: ");
                String num4 = sc.nextLine();
                divisionBase7(num3, num4);
                break;
            default:
                throw new AssertionError("Opcion incorrecta.");
        }
    }

}


