/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenkevinparte1;

/**
 *
 * @author Kevin Hernández García
 */
public class Ejercicio2 {
    public static int cuadradoSumaMenosSumaCuadrados(int n){
        int primeraSuma=0;
        int segundaSuma=0;
        for (int i = 0; i <= n; i++) {
            primeraSuma+=i;
        }
        primeraSuma = (int)Math.pow(primeraSuma, 2);
        for (int i = 1; i <= n; i++) {
            segundaSuma+=(int)Math.pow(i, 2);
        }
        
        return primeraSuma - segundaSuma;
    
    }
    public static void main(String[] args) {
        System.out.println(cuadradoSumaMenosSumaCuadrados(10));
    }
}
